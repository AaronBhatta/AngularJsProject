var myTable = angular.module('myTableDirective', []);

myTable.directive('myTableDirective', function() {
    
    var directive = {};
    directive.restrict = 'E';
    directive.scope = {
        
        apiNamesIteratelist: "=",
        result: "=",
    },
        directive.template=
        '<table class ="table table-border"><thead id ="mainheader"><th>#</th><th ng-repeat="apinames in apiNamesIterateList">{{apinames}}</th></thead><tbody><tr ng-repeat = "record in result"><td></td><td ng-repeat="(key,field) in record"><span ng-if="apiNamesIterateList.includes(key)">{{field}}</span><span ng-if="!apiNamesIterateList.includes(key)">NA</span></td></tr></tbody></table>';
        return directive;
    });