var app=angular.module("myNewApp", ["myNewFactory", "myTableDirective","toaster",'ngAnimate']);
app.controller('myController', ['$scope', 'myNewFactory','toaster', function($scope,factory,toaster){
    $scope.apiNamesListDisplay=[];
    $scope.isVisible=false;
    $scope.isVisibleNew=false;
    $scope.isSelectedFieldVisible=false; 
    $scope.accountVisible=false;
    $scope.conatctVisible=false;
    $scope.jobvisible=false;
    $scope.candidateVisible=false;
    $scope.contactShow=false;
    $scope.AccountShow=false;
    $scope.apiNamesIterateList = [];
    $scope.edit=[];
    $scope.object=[];
    $scope.fieldAndValues=new Map();
    $scope.recordToBeUpdated={};
    $scope.objectRecord={};
    
    $scope.myFunc = function(sObject) {
        $scope.isSelectedFieldVisible=true;
        $scope.result = [];
        $scope.apiNames = [];
        $scope.sObjects = sObject;
        factory.getApiNameAllField (sObject,getApiNamesSuccess, onError); 
        $scope.onEdit=function(record){
            $scope.edit=record;
            $scope.myFunctionGet(); 
        }
        function getApiNamesSuccess(result){
            console.log('Result from factory'+result);
            $scope.apiNames = result;
            toaster.pop('success', "success", "All Fields Name Fetch  Sucessfully");
            $scope.$apply();
            console.log('Result in variable'+$scope.apiNames);
        }
        
        switch($scope.sObjects){
            case 'Account':
                $scope.accountShow=true;
                $scope.conatctShow=false;
                //$scope.jobvisible=false;
                // $scope.candidateVisible=false;
                break;
            case 'Contact':
                $scope.accountShow=false;
                $scope.conatctShow=true;
                // $scope.jobvisible=false;
                // $scope.candidateVisible=false;
                break;
                ///  case 'job_vivek__c':
                //  $scope.accountVisible=false;
                // $scope.conatctVisible=false;
                // $scope.jobvisible=true;
                // $scope.candidateVisible=false;
                // break;
            case 'Candidate_Aaron__c':
                $scope.candidateShow=true;
                $scope.accountShow=false;
                $scope.conatctShow=false;
                //   $scope.candidateVisible=true;
                //  break;
        }
        function onError(message){
            toaster.pop('error', "error", "fetch failed");
            $scope.$apply();
        }
    }
    $scope.apiNamesList = [];
    $scope.apiNamesUpdate = [];
    
    $scope.change = function(field, active) {
        $scope.isVisible=false;
        $scope.isVisibleNew=false;
        if (active){
            $scope.apiNamesList.push(field);
        }
        else{
            $scope.apiNamesUpdate.push(field);
        }
    }
    $scope.updateRecord = function(record){
        console.log('Ids = '+record.Id)
        $scope.fieldAndValues.forEach(function(value, key) {
            $scope.recordToBeUpdated[key]=value;
        })
        $scope.recordToBeUpdated["Id"]=record.Id;           
        var listcashDrawer = [];
        listcashDrawer.push( $scope.recordToBeUpdated);
        console.log(listcashDrawer);            
        factory.updateRecord(listcashDrawer,onSuccessMessage,onErrorMessage);
        $scope.myFunctionGet();            
    }
    $scope.onchangeField=function(key,field){        
        if($scope.fieldAndValues.has(key)){
            $scope.fieldAndValues.set(key,field);
        }else{
            $scope.fieldAndValues.set(key,field);
        }
        $scope.myFunctionGet();  
    }
    $scope.deleteRecord = function(Id){
        factory.deleteRecord($scope.sObjects,Id,onSuccessMessage,onErrorMessage);
        $scope.myFunctionGet();
        
    }
    
    $scope.myFunctionGet = function() {
        $scope.isVisible=true;
        $scope.isVisibleNew=true;
        
        var list_size=5;
        var counter=0;
        
        if($scope.apiNamesUpdate.length===0){
            for(var i=0;i<$scope.apiNamesList.length; i++) {
                $scope.apiNamesIterateList.push($scope.apiNamesList[i]);
            }
        }else{
            for(var i=0;i<$scope.apiNamesUpdate.length; i++){
                $scope.apiNamesIterateList.remove($scope.apiNamesUpdate[i]);
            }
        }
        $scope.apiNamesList.length=0;
        $scope.apiNamesUpdate.length=0;
        var query = factory.getobjectQueryCheck ($scope.apiNamesIterateList, $scope.sObjects,' LIMIT ' + list_size+' offset '+counter);        
        factory.getRecords(query,getSelectedRecordsSuccess,onErrorMessage);
        
        
        $scope.myNxt=function(){
            counter += list_size;
            var query = factory.getobjectQueryCheck ($scope.apiNamesIterateList, $scope.sObjects, ' LIMIT '+ list_size +' offset '+counter);    
            factory.getRecords (query,getSelectedRecordsSuccess, onErrorMessage);           
            
        }
        $scope.myPrev=function(){
            counter -= list_size;
            $scope.fields = factory.getObjectAllField('contact');
            var query = factory.getobjectQueryCheck ($scope.apiNamesIterateList, $scope.sObjects, ' LIMIT '+ list_size +' offset '+counter);  
            factory.getRecords (query,getSelectedRecordsSuccess, onErrorMessage);
            if(result==undefined){
                return false;
            }            
        }        
        if($scope.result.length>0){
            switch($scope.sObjects){
                case 'Account':
                    $scope.accountVisible=true;
                    $scope.conatctVisible=false;
                    $scope.jobvisible=false;
                    $scope.candidateVisible=false;
                    break;
                case 'Contact':
                    $scope.accountVisible=false;
                    $scope.conatctVisible=true;
                    $scope.jobvisible=false;
                    $scope.candidateVisible=false;
                    break;
                case 'Job_Aaron__c':
                    $scope.accountVisible=false;
                    $scope.conatctVisible=false;
                    $scope.jobvisible=true;
                    $scope.candidateVisible=false;
                    break;
                case 'Candidate_Aaron__c':
                    $scope.accountVisible=false;
                    $scope.conatctVisible=false;
                    $scope.jobvisible=false;
                    $scope.candidateVisible=true;
                    break;
            }
        }
        function getSelectedRecordsSuccess(result) {
        $scope.result = result;            
        $scope.$apply();
        toaster.pop('success', "success", "fetch sucessfully");           
        
    }
    }
    
    $scope.Insert = function() {
        $scope.mode = 'display'; 
        factory.insertAccount($scope.account.Name,$scope.account.Type,$scope.sObjects, getSelectedRecordsSuccess,onErrorMessage);
    }    
    $scope.updateContact = function() {
        console.log('Inert contqact 1111');
        $scope.mode = 'display'; 
        factory.insertContact($scope.contact.Name, getSelectedRecordsSuccess,onErrorMessage);
    }
    
    function onSuccessMessage (message){
        $scope.$apply();
        toaster.pop('success', "sucsess", "Successful");
        
    }
    
    function onErrorMessage (message){
        $scope.$apply();
        toaster.pop('error', "error", "Error Occured");
        
    }
    $scope.saveAccount=function(sObject){
        $scope.Object.attributes= {"type":"Account"};
        console.log('inside save account11111'+Account);
        alert(JSON.stringify($scope.Object));
        console.log('inside save account222222222'+Account);
        factory.setRecords (JSON.stringify($scope.sObject), getRecordsSuccess, onError);
    }
    $scope.saveJob = function(){
        $scope.object.attributes= {"type":"Job_Aaron__c"};
        factory.setRecords (JSON.stringify($scope.object), getRecordsSuccess, onError);
    }
    $scope.saveCandidate=function(){
        $scope.object.job__c =$scope.Jobs.Id; 
        $scope.object.attributes = {"type":"Candidate_Aaron__c"};
        factory.setRecords (JSON.stringify($scope.object), getRecordsSuccess, onError);
    }
    $scope.saveContact = function(){
        $scope.object.attributes = {"type":"Contact"};
        factory.setRecords (JSON.stringify($scope.object), getRecordsSuccess, onError);
    }
    $scope.searchJob=function(){
        $scope.result=[];
        var query = factory.getActivejobs();
        factory.getjobs(query,getRecordsSuccess, onError);
    }
    
    
}]);