var myTable = angular.module("myDirective", []);
//alert('Welcome')
myTable.directive ('myDirective', function() {
    alert('myDirective 2')
    var directive = {};
    directive.restrict = 'E';
    directive.scope = {
        columnheader: "=",
        result: "=",
    },
        directive.template =
        '<thead><th>{{columnheader}}</thead>';
                   
    return directive;
});